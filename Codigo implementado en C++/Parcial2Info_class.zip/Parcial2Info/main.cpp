#include <iostream>
#include <QImage>
#include <fstream>
#include <imagen.h>
using namespace std;


int main()
{
    string filename = "../Parcial2Info/images/circulo.jpeg";
    QImage im ( filename.c_str());
    Imagen imagen1;
    imagen1.resizing(im);
    return 0;
}
























