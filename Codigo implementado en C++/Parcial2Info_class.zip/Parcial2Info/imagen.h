#ifndef IMAGEN_H
#define IMAGEN_H
#include <QImage>
#include<iostream>
class Imagen
{
public://atributos de la clase
    Imagen();//constructor de la clase

    QImage resizing(QImage);//atributo para redimensionar la imagen
};

#endif // IMAGEN_H
