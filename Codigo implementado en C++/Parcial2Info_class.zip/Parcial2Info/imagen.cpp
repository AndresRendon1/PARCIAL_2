#include "imagen.h"
#include <QImage>
#include <iostream>
#include <fstream>
using namespace std;
Imagen::Imagen()
{

}

QImage Imagen::resizing(QImage im)
{
    int corranX=0,corranY=0;

    int tamanioLeds=16;

    int Rojo[tamanioLeds][tamanioLeds];
    int Azul[tamanioLeds][tamanioLeds];
    int Verde[tamanioLeds][tamanioLeds];

    float promedioRojo=0, promedioAzul=0, promedioVerde=0;

    int AnchoImagen, LargoImagen;
    float bloquesX,bloquesY;

    tamanioLeds=16; //vamos a trabajar con una matriz de 16 leds

    AnchoImagen=im.width();
    LargoImagen=im.height();

    cout<<"Ancho de la imagen es: "<<AnchoImagen<<" y largo de imagen es: "<<LargoImagen<<endl;

    bloquesY=AnchoImagen/tamanioLeds; //cuantas columnas tiene que recorrer el bloque
    bloquesX=LargoImagen/tamanioLeds; //cuantas filas tiene que recorrer el bloque


    for(int filas=0;filas<tamanioLeds;filas++){

    for(int columnas=0;columnas<tamanioLeds;columnas++){

        for(int contadorY=0, BloqueFila=corranY ;contadorY<bloquesY;contadorY++,BloqueFila++){

            for(int contadorX=0, BloqueColumna=corranX;contadorX<bloquesX;contadorX++,BloqueColumna++){

                promedioRojo = ( promedioRojo ) + ( ( im.pixelColor(BloqueFila,BloqueColumna).red() ) / (bloquesX*bloquesY) ) ;
                promedioAzul = ( promedioAzul ) + ( ( im.pixelColor(BloqueFila,BloqueColumna).blue() ) / (bloquesX*bloquesY) ) ;
                promedioVerde = ( promedioVerde ) + ( ( im.pixelColor(BloqueFila,BloqueColumna).green() ) / (bloquesX*bloquesY) ) ;
            }
        }
        corranX=corranX+bloquesX;

        Rojo[filas][columnas]=promedioRojo;
        Azul[filas][columnas]=promedioAzul;
        Verde[filas][columnas]=promedioVerde;

        promedioRojo=0,promedioAzul=0,promedioVerde=0;
    }
        corranY=corranY+bloquesY;
        corranX=0;
    }


    int contador=0;
    ofstream guardar;
    guardar.open("../Parcial2Info/images/ImagenRedimensionada.txt",ios::out); //abriendo el archivo
    for(int i=0; i < tamanioLeds ; i++){
        for(int j=0 ; j<tamanioLeds ; j++){
            guardar<<"pixels.setPixelColor("<<contador<<","<<Rojo[i][j]<<","<<Verde[i][j]<<","<<Azul[i][j]<<");"<<endl;
            contador++;
        }
    }

//    for(int i=0; i<tamanioLeds; i++){
//        for(int j=0; j<tamanioLeds; j++){
//            //guardar<<"pixels.setPixelColor("<<i+j<<","<<Rojo[i][j]<<","<<Verde[i][j]<<","<<Azul[i][j]<<");";
//            //guardar<<"\n";
//            guardar<<"hola";
//        }
//    }
    guardar.close();
    return im;
}
