#include <iostream>
#include <QImage>
#include <fstream>
#include <imagen.h>
using namespace std;


int main()
{
    string filename = "../Parcial2Info/images/ArgentinaSub";
    QImage im ( filename.c_str());
    Imagen imagen1;



    cout<<im.height()<<" - "<<im.width()<<endl;

    if(im.height()>=16 && im.width()>=16) imagen1.Sobremuestreo(im);
    if(im.height()<16 && im.width()<16) imagen1.Submuestreo(im);
    if(im.height()>16 && im.width()<16) imagen1.SobresYSubMuestreo(im);
    if(im.height()<16 && im.width()>16) imagen1.SubYSobreMuestreo(im);

    return 0;
}
























