#include <iostream>
#include <QImage>

using namespace std;

int main()
{
    string archivo="../imagenes/images/circulo.jpg";//indicamos la ruta donde esta guardada la imagen
    QImage im(archivo.c_str());//objeto de la clase QImage asi abrimos la imagen
    //unsigned int pixelx=202;//pos pixel en x
    //unsigned int pixely=202;//pos pixel en y
    //cout<<"Intensidad del Rojo: "<<im.pixelColor(pixelx,pixely).red()<<endl;
    //cout<<"Intensidad del Rojo: "<<im.pixelColor(pixelx,pixely).green()<<endl;
    //cout<<"Intensidad del Rojo: "<<im.pixelColor(pixelx,pixely).blue()<<endl;
    cout<<"Redimensionando imagen..."<<endl;

    int ancho = im.width();//Se obtiene el ancho
    int alto = im.height();//Se obtiene el alto
    for(int i=0;i<ancho*alto;i+=(alto/16)){
        for(int y=i;y<(alto/16);y++){
            for(int j=0;j<(ancho/16);j++){
            cout<<y<<" "<<j<<endl;
            }
        }
    }
    /*for(int i=0;i<8;i++){
        for(int j=0;j<8;j++){
            pixelmedx=pixelmedx-1;
            pixelmedy=pixelmedy-1;
            cout<<pixelmedy<<","<<pixelmedx<<endl;
        }
    }*/

    //ancho = ancho/25;
    //alto = alto/25;

    //im=im.scaled(alto,ancho,Qt::KeepAspectRatio);
    //cout<<ancho<<","<<alto<<endl;
    //cout<<"Imagen redimensionada con exito: "<<im.width()<<endl;
    //cout<<"Imagen redimensionada con exito: "<<im.height()<<endl;
    /*for(int i=0;i<16;i++){
        for(int j=0;j<16;j++){
            unsigned int pixelx=i;
            unsigned int pixely=j;
            cout<<endl;
            cout<<"pixel: "<<"["<<i<<"]["<<j<<"]"<<endl;
            cout<<"Intensidad R: "<<im.pixelColor(pixelx,pixely).red()<<endl;
            cout<<"Intensidad G: "<<im.pixelColor(pixelx,pixely).green()<<endl;
            cout<<"Intensidad B: "<<im.pixelColor(pixelx,pixely).blue()<<endl;
        }
        //cout<<endl;
    }*/
    return 0;
}
