#ifndef IMAGEN_H
#define IMAGEN_H
#include <QImage>
#include<iostream>
class Imagen
{
public://atributos de la clase
    Imagen();//constructor de la clase

    QImage Sobremuestreo(QImage);//atributo para sobremuestreo de las imagenes
    QImage Submuestreo(QImage);
    QImage SobresYSubMuestreo(QImage);
    QImage SubYSobreMuestreo(QImage);


};

#endif // IMAGEN_H
