#include <iostream>
#include <fstream>
using namespace std;
ofstream guardar;
int main()
{
    guardar.open("guardar.txt",ios::out);

    for(int i=0;i<256;i++){
        int rojo=rand()%255;
        int azul=rand()%255;
        int verde=rand()%255;
        guardar<<"pixels.setPixelColor("<<i<<","<<rojo<<","<<verde<<","<<azul<<");";
        guardar<<"\n";
    }
    guardar.close();
    return 0;
}
