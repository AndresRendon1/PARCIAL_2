#include "imagen.h"
#include <QImage>
#include <iostream>
#include <fstream>
using namespace std;
Imagen::Imagen()
{

}


//SOBREMUESTREO


QImage Imagen::Sobremuestreo(QImage im)
{
    int corranX=0,corranY=0;

    int tamanioLeds=16;

    int Rojo[tamanioLeds][tamanioLeds];
    int Azul[tamanioLeds][tamanioLeds];
    int Verde[tamanioLeds][tamanioLeds];

    float promedioRojo=0, promedioAzul=0, promedioVerde=0;

    int AnchoImagen, LargoImagen;
    float bloquesX,bloquesY;

    tamanioLeds=16; //vamos a trabajar con una matriz de 16 leds

    AnchoImagen=im.width();
    LargoImagen=im.height();

    cout<<"Ancho de la imagen es: "<<AnchoImagen<<" y largo de imagen es: "<<LargoImagen<<endl;

    bloquesY=AnchoImagen/tamanioLeds; //cuantas columnas tiene que recorrer el bloque
    bloquesX=LargoImagen/tamanioLeds; //cuantas filas tiene que recorrer el bloque


    for(int filas=0;filas<tamanioLeds;filas++){

    for(int columnas=0;columnas<tamanioLeds;columnas++){

        for(int contadorY=0, BloqueFila=corranY ;contadorY<bloquesY;contadorY++,BloqueFila++){

            for(int contadorX=0, BloqueColumna=corranX;contadorX<bloquesX;contadorX++,BloqueColumna++){

                promedioRojo = ( promedioRojo ) + ( ( im.pixelColor(BloqueFila,BloqueColumna).red() ) / (bloquesX*bloquesY) ) ;
                promedioAzul = ( promedioAzul ) + ( ( im.pixelColor(BloqueFila,BloqueColumna).blue() ) / (bloquesX*bloquesY) ) ;
                promedioVerde = ( promedioVerde ) + ( ( im.pixelColor(BloqueFila,BloqueColumna).green() ) / (bloquesX*bloquesY) ) ;
            }
        }
        corranX=corranX+bloquesX;

        Rojo[filas][columnas]=promedioRojo;
        Azul[filas][columnas]=promedioAzul;
        Verde[filas][columnas]=promedioVerde;

        promedioRojo=0,promedioAzul=0,promedioVerde=0;
    }
        corranY=corranY+bloquesY;
        corranX=0;
    }


    int contador=0;
    ofstream guardar;
    guardar.open("../Parcial2Info/images/ImagenRedimensionada.txt",ios::out); //abriendo el archivo
    for(int i=0; i < tamanioLeds ; i++){
        for(int j=0 ; j<tamanioLeds ; j++){
            guardar<<"pixels.setPixelColor("<<contador<<","<<Rojo[i][j]<<","<<Verde[i][j]<<","<<Azul[i][j]<<");"<<endl;
            contador++;
        }
    }
    guardar.close();

    cout<<"Funciona"<<endl;

    return im;
}




//SUBMUESTREO

QImage Imagen::Submuestreo(QImage im)
{

    long long LargoImagen = im.width();//Se obtiene el ancho
    long long AnchoImagen = im.height();//Se obtiene el alto

    cout<<"Tamanio de la imagen es: "<<LargoImagen<<","<<AnchoImagen<<endl;

    int tamanioLeds;


    tamanioLeds=16; //tamanio de la matriz cuadrada con la que vamos a trabajar los leds


    cout<<"Alto de la redimension es: "<<tamanioLeds*LargoImagen<<" - ancho de la redimension es: "<<tamanioLeds*AnchoImagen<<endl;


    int long long recorreX=0,recorreY=0;
    int pixelRojo,pixelVerde,pixelAzul;

    long long rojo[tamanioLeds*LargoImagen][tamanioLeds*AnchoImagen], verde[tamanioLeds*LargoImagen][tamanioLeds*AnchoImagen],azul[tamanioLeds*LargoImagen][tamanioLeds*AnchoImagen];

    //long long contadorPrueba=0;

    //if(AnchoImagen<tamanioLeds && LargoImagen<tamanioLeds){

        for(int filas=0;filas<LargoImagen;filas++){


            for(int columnas=0;columnas<AnchoImagen;columnas++){


                pixelRojo=im.pixelColor(filas,columnas).red();
                pixelVerde=im.pixelColor(filas,columnas).green();
                pixelAzul=im.pixelColor(filas,columnas).blue();


                for(int contadorY=0, bloqueFila=recorreY;contadorY<tamanioLeds;contadorY++,bloqueFila++){

                    for(int contadorX=0, bloqueColumna=recorreX;contadorX<tamanioLeds;contadorX++,bloqueColumna++){

                        rojo[bloqueFila][bloqueColumna]=pixelRojo;
                        verde[bloqueFila][bloqueColumna]=pixelVerde;
                        azul[bloqueFila][bloqueColumna]=pixelAzul;
                        //cout<<"posicion fila: "<<bloqueFila<<" - posicion columna: "<<bloqueColumna<<" = "<<redimension[bloqueFila][bloqueColumna]<<endl;
                        //contadorPrueba++;
                    }
                }
                recorreX=recorreX+tamanioLeds;
            }
            recorreY=recorreY+tamanioLeds;
            recorreX=0;
        }
    //}


    //REDIMENSION A 16X6


    //cout<<contadorPrueba<<endl;


    tamanioLeds=16; //tamanio de la matriz cuadrada con la que vamos a trabajar los leds


    int corranX=0,corranY=0;
    float promedioRojo=0,promedioAzul=0,promedioVerde=0;
    int matrizRojo[tamanioLeds][tamanioLeds],matrizVerde[tamanioLeds][tamanioLeds],matrizAzul[tamanioLeds][tamanioLeds]; //la matriz de leds
    float bloquesX,bloquesY;



    bloquesY=tamanioLeds*LargoImagen / tamanioLeds; //cuantas columnas tiene que recorrer el bloque
    bloquesX=tamanioLeds*AnchoImagen / tamanioLeds;


    for(int filas=0;filas<tamanioLeds;filas++){

    for(int columnas=0;columnas<tamanioLeds;columnas++){

        for(int contadorY=0, BloqueFila=corranY ;contadorY<bloquesY;contadorY++,BloqueFila++){


            for(int contadorX=0, BloqueColumna=corranX;contadorX<bloquesX;contadorX++,BloqueColumna++){


                promedioRojo = ( promedioRojo ) + ( ( rojo[BloqueFila][BloqueColumna] ) / (bloquesX*bloquesY) ) ;
                promedioAzul = ( promedioAzul ) + ( ( azul[BloqueFila][BloqueColumna] ) / (bloquesX*bloquesY) ) ;
                promedioVerde = ( promedioVerde ) + ( ( verde[BloqueFila][BloqueColumna] ) / (bloquesX*bloquesY) ) ;

            }
        }
        corranX=corranX+bloquesX;

        matrizRojo[filas][columnas]=promedioRojo;
        matrizAzul[filas][columnas]=promedioAzul;
        matrizVerde[filas][columnas]=promedioVerde;

        promedioRojo=0,promedioAzul=0,promedioVerde=0;


    }
        corranY=corranY+bloquesY;
        corranX=0;
    }



    int contador=0;
    ofstream guardar;
    guardar.open("../Parcial2Info/images/ImagenRedimensionada.txt",ios::out); //abriendo el archivo
    for(int i=0; i < tamanioLeds ; i++){
        for(int j=0 ; j<tamanioLeds ; j++){
            guardar<<"pixels.setPixelColor("<<contador<<","<<matrizRojo[i][j]<<","<<matrizVerde[i][j]<<","<<matrizAzul[i][j]<<");"<<endl;
            contador++;
        }
    }
    guardar.close();

    cout<<"Funciona"<<endl;

    return im;
}




//SOBRE Y SUB, 100X4

QImage Imagen::SobresYSubMuestreo(QImage im)
{

    long LargoImagen = im.width();//Se obtiene el ancho
    long AnchoImagen = im.height();//Se obtiene el alto

    cout<<"Tamanio de la imagen es: Ancho: "<<LargoImagen<<", Alto: "<<AnchoImagen<<endl;

    int tamanioLeds;


    tamanioLeds=16; //tamanio de la matriz cuadrada con la que vamos a trabajar los leds


    cout<<"Alto de la redimension es: "<<LargoImagen*tamanioLeds<<" - ancho de la redimension es: "<<AnchoImagen<<endl;


    int long long recorreX=0,recorreY=0;
    int pixelRojo,pixelVerde,pixelAzul;

    int long rojo[LargoImagen*tamanioLeds][AnchoImagen], verde[LargoImagen*tamanioLeds][AnchoImagen],azul[LargoImagen*tamanioLeds][AnchoImagen];

    //long long contadorPrueba=0;

    //if(AnchoImagen<tamanioLeds && LargoImagen<tamanioLeds){

        for(int filas=0;filas<LargoImagen;filas++){


            for(int columnas=0;columnas<AnchoImagen;columnas++){


                pixelRojo=im.pixelColor(filas,columnas).red();
                pixelVerde=im.pixelColor(filas,columnas).green();
                pixelAzul=im.pixelColor(filas,columnas).blue();


                for(int contadorY=0, bloqueFila=recorreY;contadorY<tamanioLeds;contadorY++,bloqueFila++){

                    for(int contadorX=0, bloqueColumna=recorreX;contadorX<1;contadorX++,bloqueColumna++){

                        rojo[bloqueFila][bloqueColumna]=pixelRojo;
                        verde[bloqueFila][bloqueColumna]=pixelVerde;
                        azul[bloqueFila][bloqueColumna]=pixelAzul;
                        //cout<<"posicion fila: "<<bloqueFila<<" - posicion columna: "<<bloqueColumna<<" = "<<redimension[bloqueFila][bloqueColumna]<<endl;
                        //contadorPrueba++;
                    }
                }
                recorreX=recorreX+1;
            }
            recorreY=recorreY+tamanioLeds;
            recorreX=0;
        }
    //}


    //REDIMENSION A 16X6


    //cout<<contadorPrueba<<endl;


    tamanioLeds=16; //tamanio de la matriz cuadrada con la que vamos a trabajar los leds


    int corranX=0,corranY=0;
    float promedioRojo=0,promedioAzul=0,promedioVerde=0;
    int matrizRojo[tamanioLeds][tamanioLeds],matrizVerde[tamanioLeds][tamanioLeds],matrizAzul[tamanioLeds][tamanioLeds]; //la matriz de leds
    float bloquesX,bloquesY;



    bloquesY=LargoImagen * tamanioLeds / tamanioLeds; //cuantas columnas tiene que recorrer el bloque
    bloquesX=AnchoImagen / tamanioLeds;


    for(int filas=0;filas<tamanioLeds;filas++){

    for(int columnas=0;columnas<tamanioLeds;columnas++){

        for(int contadorY=0, BloqueFila=corranY ;contadorY<bloquesY;contadorY++,BloqueFila++){


            for(int contadorX=0, BloqueColumna=corranX;contadorX<bloquesX;contadorX++,BloqueColumna++){


                promedioRojo = ( promedioRojo ) + ( ( rojo[BloqueFila][BloqueColumna] ) / (bloquesX*bloquesY) ) ;
                promedioAzul = ( promedioAzul ) + ( ( azul[BloqueFila][BloqueColumna] ) / (bloquesX*bloquesY) ) ;
                promedioVerde = ( promedioVerde ) + ( ( verde[BloqueFila][BloqueColumna] ) / (bloquesX*bloquesY) ) ;

            }
        }
        corranX=corranX+bloquesX;

        matrizRojo[filas][columnas]=promedioRojo-1;
        matrizAzul[filas][columnas]=promedioAzul-1;
        matrizVerde[filas][columnas]=promedioVerde-1;

        promedioRojo=0,promedioAzul=0,promedioVerde=0;


    }
        corranY=corranY+bloquesY;
        corranX=0;
    }






    int contador=0;
    ofstream guardar;
    guardar.open("../Parcial2Info/images/ImagenRedimensionada.txt",ios::out); //abriendo el archivo
    for(int i=0; i < tamanioLeds ; i++){
        for(int j=0 ; j<tamanioLeds ; j++){
            if(matrizRojo[i][j]<0) matrizRojo[i][j]=0;
            if(matrizAzul[i][j]<0) matrizAzul[i][j]=0;
            if(matrizVerde[i][j]<0) matrizVerde[i][j]=0;
            guardar<<"pixels.setPixelColor("<<contador<<","<<matrizRojo[i][j]<<","<<matrizVerde[i][j]<<","<<matrizAzul[i][j]<<");"<<endl;
            contador++;
        }
    }
    guardar.close();

    cout<<"Funciona"<<endl;


    return im;

}




//SUBMUESTREO Y SOBREMUESTREO. 4X100
QImage Imagen::SubYSobreMuestreo(QImage im)
{


    long LargoImagen = im.width();//Se obtiene el ancho
    long AnchoImagen = im.height();//Se obtiene el alto

    cout<<"Tamanio de la imagen es: Ancho: "<<LargoImagen<<", Alto: "<<AnchoImagen<<endl;

    int tamanioLeds;


    tamanioLeds=16; //tamanio de la matriz cuadrada con la que vamos a trabajar los leds


    cout<<"Alto de la redimension es: "<<LargoImagen<<" - ancho de la redimension es: "<<AnchoImagen*tamanioLeds<<endl;


    int long long recorreX=0,recorreY=0;
    int pixelRojo,pixelVerde,pixelAzul;

    int long rojo[LargoImagen][AnchoImagen*tamanioLeds], verde[LargoImagen][AnchoImagen*tamanioLeds],azul[LargoImagen][AnchoImagen*tamanioLeds];

    //long long contadorPrueba=0;

    //if(AnchoImagen<tamanioLeds && LargoImagen<tamanioLeds){

        for(int filas=0;filas<LargoImagen;filas++){


            for(int columnas=0;columnas<AnchoImagen;columnas++){


                pixelRojo=im.pixelColor(filas,columnas).red();
                pixelVerde=im.pixelColor(filas,columnas).green();
                pixelAzul=im.pixelColor(filas,columnas).blue();


                for(int contadorY=0, bloqueFila=recorreY;contadorY<1;contadorY++,bloqueFila++){

                    for(int contadorX=0, bloqueColumna=recorreX;contadorX<tamanioLeds;contadorX++,bloqueColumna++){

                        rojo[bloqueFila][bloqueColumna]=pixelRojo;
                        verde[bloqueFila][bloqueColumna]=pixelVerde;
                        azul[bloqueFila][bloqueColumna]=pixelAzul;
                        //cout<<"posicion fila: "<<bloqueFila<<" - posicion columna: "<<bloqueColumna<<" = "<<redimension[bloqueFila][bloqueColumna]<<endl;
                        //contadorPrueba++;
                    }
                }
                recorreX=recorreX+tamanioLeds;
            }
            recorreY=recorreY+1;
            recorreX=0;
        }
    //}


    //REDIMENSION A 16X6


    //cout<<contadorPrueba<<endl;


    tamanioLeds=16; //tamanio de la matriz cuadrada con la que vamos a trabajar los leds


    int corranX=0,corranY=0;
    float promedioRojo=0,promedioAzul=0,promedioVerde=0;
    int matrizRojo[tamanioLeds][tamanioLeds],matrizVerde[tamanioLeds][tamanioLeds],matrizAzul[tamanioLeds][tamanioLeds]; //la matriz de leds
    float bloquesX,bloquesY;



    bloquesY=LargoImagen  / tamanioLeds; //cuantas columnas tiene que recorrer el bloque
    bloquesX=AnchoImagen * tamanioLeds/ tamanioLeds;


    for(int filas=0;filas<tamanioLeds;filas++){

    for(int columnas=0;columnas<tamanioLeds;columnas++){

        for(int contadorY=0, BloqueFila=corranY ;contadorY<bloquesY;contadorY++,BloqueFila++){


            for(int contadorX=0, BloqueColumna=corranX;contadorX<bloquesX;contadorX++,BloqueColumna++){


                promedioRojo = ( promedioRojo ) + ( ( rojo[BloqueFila][BloqueColumna] ) / (bloquesX*bloquesY) ) ;
                promedioAzul = ( promedioAzul ) + ( ( azul[BloqueFila][BloqueColumna] ) / (bloquesX*bloquesY) ) ;
                promedioVerde = ( promedioVerde ) + ( ( verde[BloqueFila][BloqueColumna] ) / (bloquesX*bloquesY) ) ;

            }
        }
        corranX=corranX+bloquesX;

        matrizRojo[filas][columnas]=promedioRojo-1;
        matrizAzul[filas][columnas]=promedioAzul-1;
        matrizVerde[filas][columnas]=promedioVerde-1;

        promedioRojo=0,promedioAzul=0,promedioVerde=0;


    }
        corranY=corranY+bloquesY;
        corranX=0;
    }






    int contador=0;
    ofstream guardar;
    guardar.open("../Parcial2Info/images/ImagenRedimensionada.txt",ios::out); //abriendo el archivo
    for(int i=0; i < tamanioLeds ; i++){
        for(int j=0 ; j<tamanioLeds ; j++){
            if(matrizRojo[i][j]<0) matrizRojo[i][j]=0;
            if(matrizAzul[i][j]<0) matrizAzul[i][j]=0;
            if(matrizVerde[i][j]<0) matrizVerde[i][j]=0;
            guardar<<"pixels.setPixelColor("<<contador<<","<<matrizRojo[i][j]<<","<<matrizVerde[i][j]<<","<<matrizAzul[i][j]<<");"<<endl;
            contador++;
        }
    }
    guardar.close();

    cout<<"Funciona"<<endl;

    return im;
}







































































